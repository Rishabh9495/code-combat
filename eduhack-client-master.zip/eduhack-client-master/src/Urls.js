export const URLS = {
    baseUrl: "/auth",
    login: "/user/login",
    register: "/user/register"
}