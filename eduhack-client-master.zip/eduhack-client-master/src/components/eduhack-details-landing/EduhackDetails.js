import React from 'react';

const EduhackDetails = () => {
    return (
        <div>
            What is EduHack?
        </div>
    );
}

export default EduhackDetails;
